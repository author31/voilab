"""
Standalone Isaac Sim evaluation without Hydra (Python 3.11 friendly).
Uses the shared registry system for task configuration (kitchen, dining-room, living-room).
.venv/bin/python scripts/run_isaacsim_eval.py --task kitchen --checkpoint data/outputs/2026.01.25/22.51.20_train_diffusion_unet_timm_umi/checkpoints/latest.ckpt --output-dir ./tmp/eval
Example:
    python run_isaacsim_eval.py --task kitchen --checkpoint /path/to.ckpt --output-dir /tmp/eval
"""

import argparse
import importlib
import json
import pathlib
from typing import Any, Dict, List, Optional, Tuple

import dill
import numpy as np
import torch
from scipy.spatial.transform import Rotation as R


try:
    from omegaconf import OmegaConf
except Exception:
    OmegaConf = None  # type: ignore

import registry

# --- Constants ---
BASE_SCENE_FP = "/workspace/voilab/assets/ED305_scene/ED305.usd"
FRANKA_PANDA_FP = "/workspace/voilab/assets/franka_panda/franka_panda_arm.usd"
FRANKA_PANDA_PRIM_PATH = "/World/Franka"
GOPRO_PRIM_PATH = "/World/Franka/panda/panda_link7/gopro_link"
ASSETS_DIR = "/workspace/voilab/assets/CADs"

# Lula IK config paths
LULA_ROBOT_DESCRIPTION_PATH = "/workspace/voilab/assets/lula/frank_umi_descriptor.yaml"
LULA_URDF_PATH = "/workspace/voilab/assets/franka_panda/franka_panda_umi-isaacsim.urdf"

# Task name to runner class mapping
TASK_RUNNER_MAP = {
    "kitchen": "diffusion_policy.env_runner.isaacsim_registry_runners.KitchenIsaacSimAppRunner",
    "dining-room": "diffusion_policy.env_runner.isaacsim_registry_runners.DiningRoomIsaacSimAppRunner",
    "living-room": "diffusion_policy.env_runner.isaacsim_registry_runners.LivingRoomIsaacSimAppRunner",
}


def rot6d_to_rotation_matrix(rot6d: np.ndarray) -> np.ndarray:
    """
    Convert 6D rotation representation to 3x3 rotation matrix.
    Uses Gram-Schmidt orthogonalization (Zhou et al., 2019).

    Args:
        rot6d: (6,) array representing first two columns of rotation matrix

    Returns:
        (3, 3) rotation matrix
    """
    a1 = rot6d[:3]
    a2 = rot6d[3:6]

    # Normalize first vector
    b1 = a1 / (np.linalg.norm(a1) + 1e-8)

    # Orthogonalize second vector
    b2 = a2 - np.dot(b1, a2) * b1
    b2 = b2 / (np.linalg.norm(b2) + 1e-8)

    # Cross product for third vector
    b3 = np.cross(b1, b2)

    return np.stack([b1, b2, b3], axis=1)


def set_gripper_width(panda, width: float, threshold: float = 0.04, step: float = 0.01):
    """
    Threshold-based gripper control with gradual movement.

    Args:
        panda: Robot articulation
        width: Input gripper width from policy
        threshold: Threshold to determine open (>=) or closed (<)
        step: Amount to change finger position per call
    """
    target_pos = 1.0 if width >= threshold else 0.0

    idx1 = panda.get_dof_index("panda_finger_joint1")
    idx2 = panda.get_dof_index("panda_finger_joint2")

    if idx1 is not None and idx2 is not None:
        current_positions = panda.get_joint_positions(
            joint_indices=np.array([idx1, idx2])
        )
        current_pos = current_positions[0]

        # Smaller steps for closing (grasping)
        if target_pos < current_pos:
            step = min(step, 0.005)
            if abs(current_pos - target_pos) < 0.02:
                step = 0.002

        # Move gradually toward target
        if current_pos < target_pos:
            finger_pos = min(current_pos + step, target_pos)
        elif current_pos > target_pos:
            finger_pos = max(current_pos - step, target_pos)
        else:
            finger_pos = target_pos

        panda.set_joint_positions(
            positions=np.array([finger_pos, finger_pos]),
            joint_indices=np.array([idx1, idx2]),
        )


class IsaacSimEnvironment:
    """
    Isaac Sim environment wrapper with IK-based action execution.

    Handles:
    - SimulationApp lifecycle
    - World/scene setup from registry config
    - Robot spawning and IK solver initialization
    - Action execution (position + rot6d + gripper -> IK -> joint commands)
    - Observation capture (RGB + proprioception)

    Coordinate System Note:
    - Training data uses RELATIVE pose representation by default (obs_pose_repr='rel')
    - Actions predicted by policy are RELATIVE to the last observation pose
    - This class converts relative actions to absolute world-frame poses before IK
    """

    def __init__(
        self,
        task_name: str,
        sim_config: Optional[Dict[str, Any]] = None,
        shape_meta: Optional[Dict[str, Any]] = None,
        pose_repr: Optional[Dict[str, str]] = None,
    ) -> None:
        self.task_name = task_name
        self.shape_meta = shape_meta or {}
        self._obs_history: Dict[str, List[np.ndarray]] = {}

        # Pose representation configuration (from training)
        # Defaults match umi_dataset.py defaults
        self.pose_repr = pose_repr or {}
        self.obs_pose_repr = self.pose_repr.get("obs_pose_repr", "rel")
        self.action_pose_repr = self.pose_repr.get("action_pose_repr", "rel")

        # Load configuration from registry
        registry_class = registry.get_task_registry(task_name)
        if not registry_class.validate_environment():
            print(
                f"[IsaacSimEnvironment] WARNING: Registry validation failed for {task_name}"
            )
        self.registry_config = registry_class.get_config()
        self.is_episode_completed = registry_class.is_episode_completed

        # IK solver references (initialized after world setup)
        self.lula_solver = None
        self.art_kine_solver = None
        self.manipulator = None

        # Pose tracking for relative observations and actions
        self._initial_eef_rot: Optional[np.ndarray] = None
        self._last_eef_pos: Optional[np.ndarray] = None
        self._last_eef_rot: Optional[np.ndarray] = None

        default_sim_config = {
            "headless": False,
            "width": 1280,
            "height": 720,
            "enable_streaming": False,
            "extensions": ["isaacsim.robot_motion.motion_generation"],
        }
        merged_sim_config = {**default_sim_config, **(sim_config or {})}

        print("[IsaacSimEnvironment] Starting SimulationApp...")
        from isaacsim import SimulationApp

        self.simulation_app = SimulationApp(merged_sim_config)
        self.world = None
        self.camera = None
        self.first = False
        self.tmp = None
        import omni.kit.app

        # 獲取擴展管理器
        ext_manager = omni.kit.app.get_app().get_extension_manager()

        # 檢查並立即啟動 debug_draw 擴展
        extension_id = "isaacsim.util.debug_draw"
        if not ext_manager.is_extension_enabled(extension_id):
            ext_manager.set_extension_enabled_immediate(extension_id, True)
        try:
            self._initialize_world_and_camera()
            self._initialize_ik_solvers()
        except Exception as e:
            print(f"[IsaacSimEnvironment] Initialization error: {e}")
            import traceback

            traceback.print_exc()

    def show_cameras(env):
        rgb_wrist = env.cameras["wrist"].get_rgb()
        rgb_top   = env.cameras["top"].get_rgb()
        rgb_angle = env.cameras["angle"].get_rgb()

        # 轉成 uint8 (假設是 0-1 float)
        rgb_wrist = (rgb_wrist * 255).astype(np.uint8) if rgb_wrist.dtype==np.float32 else rgb_wrist
        rgb_top   = (rgb_top * 255).astype(np.uint8) if rgb_top.dtype==np.float32 else rgb_top
        rgb_angle = (rgb_angle * 255).astype(np.uint8) if rgb_angle.dtype==np.float32 else rgb_angle

        # RGB -> BGR
        rgb_wrist = cv2.cvtColor(rgb_wrist, cv2.COLOR_RGB2BGR)
        rgb_top   = cv2.cvtColor(rgb_top, cv2.COLOR_RGB2BGR)
        rgb_angle = cv2.cvtColor(rgb_angle, cv2.COLOR_RGB2BGR)

        # 顯示
        cv2.imshow("Wrist Camera", rgb_wrist)
        cv2.imshow("Top Camera", rgb_top)
        cv2.imshow("Angle Camera", rgb_angle)

        cv2.waitKey(1)  # 1 ms 更新

    def draw_line(self, p0, p1, color=(0, 1, 0, 1), thickness=2):
        # 所有的參數都必須包裝成 List
        self.debug_draw.draw_lines(
            [tuple(p0.tolist())],      # 起點列表
            [tuple(p1.tolist())],      # 終點列表
            [color],                   # 顏色列表 (關鍵：加中括號)
            [float(thickness)],        # 粗細列表 (關鍵：加中括號)
        )

    def draw_point(self, pos, color=(1, 0, 0, 1), size=5):
        # 同理，draw_points 也需要 List
        self.debug_draw.draw_points(
            [tuple(pos.tolist())],     # 點位列表
            [color],                   # 顏色列表
            [float(size)],             # 大小列表
        )
    def draw_frame(self, pos, rot_mat, scale=0.1):
        pos = pos.reshape(3)

        x = rot_mat[:, 0]
        y = rot_mat[:, 1]
        z = rot_mat[:, 2]

        self.draw_line(pos, pos + scale * x, color=(1, 0, 0, 1), thickness=3)  # X
        self.draw_line(pos, pos + scale * y, color=(0, 1, 0, 1), thickness=3)  # Y
        self.draw_line(pos, pos + scale * z, color=(0, 0, 1, 1), thickness=3)  # Z
    def draw_trajectory(self, points, color=(1, 1, 1, 1), thickness=2, closed=False):
        pts = [tuple(p.tolist()) for p in points]
        self.debug_draw.draw_lines_spline(
            pts,
            color,
            thickness,
            closed,
        )
        
    def calculate_camera_orientation(self, eye_pos, target_pos, up_axis=np.array([0, 0, 1])):
        """
        Helper function.
        Computes the quaternion (WXYZ) for a Robotics Camera (Look=X, Up=Z)
        at eye_pos looking at target_pos.
        """
        eye_pos = np.array(eye_pos)
        target_pos = np.array(target_pos)
        
        # 1. Forward Vector (Camera X-axis)
        fwd = target_pos - eye_pos
        fwd = fwd / np.linalg.norm(fwd)
        
        # 2. Right Vector
        right = np.cross(fwd, up_axis)
        
        # Handle degenerate case (looking straight up/down)
        if np.linalg.norm(right) < 1e-6:
            right = np.array([0, 1, 0])
            
        right = right / np.linalg.norm(right)
        
        # 3. Up Vector (Camera Z-axis)
        z_axis = np.cross(right, fwd)
        z_axis = z_axis / np.linalg.norm(z_axis)
        
        # Y_axis (Camera Left)
        y_axis = np.cross(z_axis, fwd)
        y_axis = y_axis / np.linalg.norm(y_axis)
        
        # Basis: X=fwd, Y=y_axis, Z=z_axis
        R_matrix = np.column_stack((fwd, y_axis, z_axis))
        
        # Convert to quaternion (Scalar-Last xyzw -> WXYZ for Isaac Sim)
        quat_xyzw = R.from_matrix(R_matrix).as_quat()
        quat_wxyz = np.array([quat_xyzw[3], quat_xyzw[0], quat_xyzw[1], quat_xyzw[2]])
        
        return quat_wxyz

    def _initialize_world_and_camera(self) -> None:
        import os
        import isaacsim.core.utils.stage as stage_utils
        from isaacsim.core.api import World
        from isaacsim.core.prims import SingleXFormPrim
        from isaacsim.core.utils.extensions import enable_extension
        from isaacsim.core.utils.viewports import set_camera_view
        from isaacsim.robot.manipulators import SingleManipulator
        from isaacsim.robot.manipulators.grippers import ParallelGripper
        from isaacsim.sensors.camera import Camera
        from isaacsim.storage.native import get_assets_root_path

        assets_root_path = get_assets_root_path()
        if assets_root_path is None:
            raise RuntimeError("Could not find Isaac Sim assets folder.")

        enable_extension("isaacsim.robot_motion.motion_generation")
        stage_utils.open_stage(BASE_SCENE_FP)

        self.world = World(stage_units_in_meters=1.0)
        self.world.scene.add_default_ground_plane()

        # --- Setup robot ---
        robot = stage_utils.add_reference_to_stage(
            usd_path=FRANKA_PANDA_FP, prim_path=FRANKA_PANDA_PRIM_PATH
        )
        robot.GetVariantSet("Gripper").SetVariantSelection("AlternateFinger")
        robot.GetVariantSet("Mesh").SetVariantSelection("Quality")

        self.robot_xform = SingleXFormPrim(prim_path=FRANKA_PANDA_PRIM_PATH)

        gripper = ParallelGripper(
            end_effector_prim_path=f"{FRANKA_PANDA_PRIM_PATH}/panda/panda_rightfinger",
            joint_prim_names=["panda_finger_joint1", "panda_finger_joint2"],
            joint_opened_positions=np.array([0.05, 0.05]),
            joint_closed_positions=np.array([0.02, 0.02]),
            action_deltas=np.array([0.01, 0.01]),
        )

        self.manipulator = self.world.scene.add(
            SingleManipulator(
                prim_path=FRANKA_PANDA_PRIM_PATH,
                name="my_franka",
                end_effector_prim_path=f"{FRANKA_PANDA_PRIM_PATH}/panda/panda_rightfinger",
                gripper=gripper,
            )
        )
        self.manipulator.gripper.set_default_state(
            self.manipulator.gripper.joint_opened_positions
        )

        # --- Set robot pose ---
        franka_pose = self.registry_config.get("franka_pose", {})
        franka_translation = np.array(franka_pose.get("translation", [0.0, 0.0, 0.0]))
        franka_rotation = np.array(franka_pose.get("rotation_quat", [1.0, 0.0, 0.0, 0.0]))
        self.robot_xform.set_local_pose(
            translation=franka_translation / stage_utils.get_stage_units(),
            orientation=franka_rotation,
        )
        camera_translation = self.registry_config.get("camera_pose", {}).get("translation", [0, 0, 0])
        set_camera_view(camera_translation, franka_translation)

        # --- Setup Multi-Camera (UMI Style) ---
        self.cameras = {}
        res = (224, 224) # 統一解析度

        # 1. Wrist Camera
        self.cameras["wrist"] = Camera(
            prim_path=f"{GOPRO_PRIM_PATH}/Camera",
            name="wrist_camera",
            resolution=res
        )

        # 2. Top-Down Camera
        top_pos = franka_translation + np.array([0.6, 0.0, 1.8])
        top_target = franka_translation + np.array([0.6, 0.0, 0.0])
        top_quat = self.calculate_camera_orientation(top_pos, top_target, up_axis=np.array([1, 0, 0]))
        self.cameras["top"] = Camera(
            prim_path="/World/TopCamera",
            name="top_camera",
            position=top_pos,
            orientation=top_quat,
            resolution=res
        )

        # 3. Angle Camera
        angle_pos = franka_translation + np.array([1.6, -2.0, 1.3])
        angle_target = franka_translation + np.array([0.3, 0.0, 0.2])
        angle_quat = self.calculate_camera_orientation(angle_pos, angle_target, up_axis=np.array([0, 0, 1]))
        self.cameras["angle"] = Camera(
            prim_path="/World/AngleCamera",
            name="angle_camera",
            position=angle_pos,
            orientation=angle_quat,
            resolution=res
        )

        for cam in self.cameras.values():
            cam.initialize()

        self.world.reset()

        # --- Debug Draw Setup ---
        from isaacsim.util.debug_draw import _debug_draw
        try:
            self.debug_draw = _debug_draw.acquire_debug_draw_interface()
        except Exception:
            import isaacsim.util.debug_draw.impl as debug_impl
            self.debug_draw = debug_impl.acquire_debug_draw_interface()

        self._load_preload_objects(stage_utils)

    def _load_preload_objects(self, stage_utils) -> None:
        """Load objects specified in registry config's PRELOAD_OBJECTS at their default positions."""
        import os

        from isaacsim.core.prims import SingleXFormPrim

        env_vars = self.registry_config.get("environment_vars", {})
        preload_objects = env_vars.get("PRELOAD_OBJECTS", [])

        self.object_prims: Dict[str, Any] = {}

        for entry in preload_objects:
            raw_name = entry.get("name", "unknown")
            asset_filename = entry.get("assets")
            prim_path = entry.get("prim_path")

            if not asset_filename or not prim_path:
                print(f"[IsaacSimEnvironment] Skipping invalid preload entry: {entry}")
                continue

            full_asset_path = os.path.join(ASSETS_DIR, asset_filename)
            if not os.path.exists(full_asset_path):
                print(f"[IsaacSimEnvironment] Asset not found: {full_asset_path}")
                continue

            try:
                stage_utils.add_reference_to_stage(
                    usd_path=full_asset_path, prim_path=prim_path
                )

                default_position = entry.get("default_position")
                if default_position is not None:
                    default_position = np.array(default_position, dtype=np.float64)

                orientation = np.array(entry.get("quat_wxyz", [1, 0, 0, 0]))

                obj_prim = SingleXFormPrim(
                    prim_path=prim_path,
                    name=raw_name.replace(" ", "_"),
                    position=default_position,
                    orientation=orientation,
                )
                self.world.scene.add(obj_prim)
                self.object_prims[raw_name] = obj_prim
                print(
                    f"[IsaacSimEnvironment] Loaded {raw_name} at {prim_path}, position={default_position}"
                )
            except Exception as e:
                print(f"[IsaacSimEnvironment] Failed to load {raw_name}: {e}")

    def _reposition_objects_to_default(self) -> None:
        """Reset all preloaded objects to their default positions (for inference)."""
        if not hasattr(self, "object_prims") or not self.object_prims:
            return

        env_vars = self.registry_config.get("environment_vars", {})
        preload_objects = env_vars.get("PRELOAD_OBJECTS", [])

        for entry in preload_objects:
            raw_name = entry.get("name", "unknown")
            if raw_name not in self.object_prims:
                continue

            default_position = entry.get("default_position")
            if default_position is None:
                continue

            default_position = np.array(default_position, dtype=np.float64)
            orientation = np.array(entry.get("quat_wxyz", [1, 0, 0, 0]))

            self.object_prims[raw_name].set_local_pose(
                translation=default_position,
                orientation=orientation,
            )

    def apply_ik_solution(self, target_pos, target_quat_wxyz):
        """
        Compute and apply IK solution for target pose.
        
        Args:
            panda: Panda articulation object
            art_kine_solver: ArticulationKinematicsSolver instance
            target_pos: Target position (3,)
            target_quat_wxyz: Target orientation as quaternion WXYZ (4,)
            step_idx: Current step index (for logging)
            
        Returns:
            bool: True if IK succeeded
        """
        action, success = self.art_kine_solver.compute_inverse_kinematics(
            target_position=target_pos,
            target_orientation=target_quat_wxyz
        )

        if success:
            self.manipulator.set_joint_positions(action.joint_positions, np.arange(7))
            return True

        return False

    def _initialize_ik_solvers(self) -> None:
        """Initialize Lula IK solvers for action execution."""
        from isaacsim.robot_motion.motion_generation import (
            ArticulationKinematicsSolver,
            LulaKinematicsSolver,
        )

        print("[IsaacSimEnvironment] Initializing IK solvers...")

        self.lula_solver = LulaKinematicsSolver(
            robot_description_path=LULA_ROBOT_DESCRIPTION_PATH,
            urdf_path=LULA_URDF_PATH,
        )

        self.art_kine_solver = ArticulationKinematicsSolver(
            self.manipulator,
            kinematics_solver=self.lula_solver,
            end_effector_frame_name="umi_tcp",
        )

        # Calibrate robot base pose
        robot_pos, robot_quat = self.manipulator.get_world_pose()
        self.lula_solver.set_robot_base_pose(
            robot_position=robot_pos, robot_orientation=robot_quat
        )
        
            

    def _get_end_effector_pose(self) -> Tuple[np.ndarray, np.ndarray]:
        """
        Get current end-effector position and rotation matrix.

        Returns:
            (position (3,), rotation_matrix (3,3))
        """
        robot_pos, robot_quat = self.manipulator.get_world_pose()
        self.lula_solver.set_robot_base_pose(
            robot_position=robot_pos, robot_orientation=robot_quat
        )
        ee_pos, ee_rot_matrix = self.art_kine_solver.compute_end_effector_pose()
        return ee_pos.astype(np.float64), ee_rot_matrix[:3, :3].astype(np.float64)

    def get_end_effector_pos_quat_wxyz(self, panda, lula_solver, art_kine_solver) -> Tuple[np.ndarray, np.ndarray]:
        """Get current end-effector position and orientation as quaternion WXYZ."""
        base_pos, base_quat = panda.get_world_pose()
        lula_solver.set_robot_base_pose(robot_position=base_pos, robot_orientation=base_quat)

        ee_pos, ee_T = art_kine_solver.compute_end_effector_pose()  # ee_T[:3,:3] rotation
        quat_xyzw = R.from_matrix(ee_T[:3, :3]).as_quat()
        quat_wxyz = quat_xyzw[[3, 0, 1, 2]]
        return ee_pos.astype(np.float64), quat_wxyz.astype(np.float64)

    def _rotation_matrix_to_rot6d(self, rot_mat: np.ndarray) -> np.ndarray:
        """Convert 3x3 rotation matrix to 6D representation."""
        return rot_mat[:, :2].flatten()

    def is_running(self) -> bool:
        return bool(self.simulation_app and self.simulation_app.is_running())

    def update(self) -> None:
        if self.simulation_app:
            self.simulation_app.update()

    def _get_horizon(self, key: str) -> int:
        return int(self.shape_meta.get("obs", {}).get(key, {}).get("horizon", 1))
    def _capture_observation(self) -> Dict[str, np.ndarray]:
        """Capture current observations from the multi-camera environment, policy-ready format."""
        obs: Dict[str, np.ndarray] = {}

        # -------------------------------------------------
        # Helper: process RGB -> CHW float32
        # -------------------------------------------------
        def _process_rgb(rgb: np.ndarray) -> np.ndarray:
            if rgb is None:
                print("[DEBUG][_capture_observation] RGB is None")
                return None
            rgb = np.asarray(rgb)
            if rgb.ndim != 3:
                raise ValueError(f"RGB must be 3D, got shape {rgb.shape}")
            # HWC -> CHW
            if rgb.shape[-1] == 3:
                rgb = np.transpose(rgb, (2, 0, 1))
            # Add batch & time dimension -> (1,1,C,H,W)
            return rgb.astype(np.float32)[None, None, :, :, :]

        # -------------------------------------------------
        # 1. Multi-camera RGB
        # -------------------------------------------------
        if hasattr(self, "cameras"):
            for cam_name, key_name in [("angle", "angle_rgb"),
                                    ("top", "top_rgb"),
                                    ("wrist", "wrist_rgb")]:
                if cam_name in self.cameras:
                    rgb = _process_rgb(self.cameras[cam_name].get_rgb())
                    if rgb is not None:
                        obs[key_name] = rgb
                        print(f"[DEBUG][_capture_observation] {key_name} shape: {rgb.shape}")
                    else:
                        print(f"[DEBUG][_capture_observation] {key_name} is None")
        elif hasattr(self, "camera") and self.camera is not None:
            rgb = _process_rgb(self.camera.get_rgb())
            if rgb is not None:
                obs["camera0_rgb"] = rgb
                print(f"[DEBUG][_capture_observation] camera0_rgb shape: {rgb.shape}")
            else:
                print("[DEBUG][_capture_observation] camera0_rgb is None")

        # -------------------------------------------------
        # 2. End-effector pose (EEF) low-dim
        # -------------------------------------------------
        if self.art_kine_solver is not None and self.manipulator is not None:
            ee_pos, ee_rot_mat = self._get_end_effector_pose()
            print(f"[DEBUG][_capture_observation] EEF pos: {ee_pos}")
            print(f"[DEBUG][_capture_observation] EEF rot_mat:\n{ee_rot_mat}")

            # Position (B,T,D) -> (1,1,3)
            obs["robot0_eef_pos"] = ee_pos.astype(np.float32)[None, None, :]

            # Rotation (axis-angle or 6D) -> (1,1,6)
            rot6d = self._rotation_matrix_to_rot6d(ee_rot_mat).astype(np.float32)
            if rot6d.ndim == 1:
                rot6d = rot6d[None, None, :]
            obs["robot0_eef_rot_axis_angle"] = rot6d
            print(f"[DEBUG][_capture_observation] EEF rot6d: {rot6d}")

            # Relative rotation wrt start
            if self._initial_eef_rot is not None:
                rel_rot = self._initial_eef_rot.T @ ee_rot_mat
                rel_rot6d = self._rotation_matrix_to_rot6d(rel_rot).astype(np.float32)
                if rel_rot6d.ndim == 1:
                    rel_rot6d = rel_rot6d[None, None, :]
                obs["robot0_eef_rot_axis_angle_wrt_start"] = rel_rot6d
                print(f"[DEBUG][_capture_observation] EEF rel_rot6d wrt start: {rel_rot6d}")
            else:
                obs["robot0_eef_rot_axis_angle_wrt_start"] = rot6d

            # Gripper width (robust)
            joint_pos = np.asarray(self.manipulator.get_joint_positions(), dtype=np.float32)
            if joint_pos.shape[0] >= 2:
                gripper_width = np.abs(joint_pos[-1] - joint_pos[-2])
            else:
                gripper_width = 0.0
            obs["robot0_gripper_width"] = np.array([gripper_width], dtype=np.float32)[None, None, :]
            print(f"[DEBUG][_capture_observation] Gripper width: {gripper_width}")

        # -------------------------------------------------
        # 3. Shape-meta-aware fallback (zeros, batch/time dims)
        # -------------------------------------------------
        for key, meta in self.shape_meta.get("obs", {}).items():
            if key in obs:
                continue
            shape = meta.get("shape") or meta.get("raw_shape")
            if shape is None:
                continue
            obs[key] = np.zeros((1, 1, *shape), dtype=np.float32)
            print(f"[DEBUG][_capture_observation] Fallback obs {key} shape: {obs[key].shape}")

        return obs



    def _update_history(self, obs: Dict[str, np.ndarray]) -> None:
        for key, value in obs.items():
            history = self._obs_history.setdefault(key, [])
            history.append(value)
            max_h = self._get_horizon(key)
            if len(history) > max_h:
                self._obs_history[key] = history[-max_h:]

    def _stack_history(self) -> Dict[str, np.ndarray]:
        stacked: Dict[str, np.ndarray] = {}
        for key, history in self._obs_history.items():
            horizon = self._get_horizon(key)
            if not history:
                # 用 zeros 填滿
                shape = self.shape_meta.get("obs", {}).get(key, {}).get("shape", (1,))
                data = [np.zeros(shape, dtype=np.float32) for _ in range(horizon)]
            else:
                if len(history) < horizon:
                    pad = [history[0]] * (horizon - len(history))
                    data = pad + history
                else:
                    data = history[-horizon:]

            stacked_arr = np.stack(data, axis=0)  # [horizon, ...]
            # 只移除 size=1 的維度，不要指定 axis
            stacked_arr = stacked_arr.squeeze()
            stacked[key] = stacked_arr.astype(np.float32)

        if (
            self.obs_pose_repr in ("rel", "relative")
            and "robot0_eef_pos" in stacked
            and "robot0_eef_rot_axis_angle" in stacked
        ):
            stacked = self._convert_obs_to_relative(stacked)

        return stacked

    def _convert_obs_to_relative(self, stacked: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        pos = stacked["robot0_eef_pos"]  # [horizon, 3]
        rot6d = stacked["robot0_eef_rot_axis_angle"]  # [horizon, 6]

        if rot6d.size == 0:
            stacked["robot0_eef_pos"] = np.zeros_like(pos, dtype=np.float32)
            stacked["robot0_eef_rot_axis_angle"] = np.zeros_like(rot6d, dtype=np.float32)
            return stacked

        base_pos = pos[-1]  # [3]
        base_rot6d = rot6d[-1]  # [6]
        base_rot_mat = rot6d_to_rotation_matrix(base_rot6d)
        base_rot_inv = base_rot_mat.T

        rel_pos = np.zeros_like(pos)
        rel_rot6d = np.zeros_like(rot6d)

        for i in range(len(pos)):
            rel_pos[i] = pos[i] - base_pos
            curr_rot_mat = rot6d_to_rotation_matrix(rot6d[i])
            rel_rot_mat = curr_rot_mat @ base_rot_inv
            rel_rot6d[i] = self._rotation_matrix_to_rot6d(rel_rot_mat)

        stacked["robot0_eef_pos"] = rel_pos.astype(np.float32)
        stacked["robot0_eef_rot_axis_angle"] = rel_rot6d.astype(np.float32)

        return stacked


    def reset(self) -> Dict[str, np.ndarray]:
        if self.world is None:
            raise RuntimeError("IsaacSimEnvironment is not initialized with a world.")

        self.world.reset()
        self._reposition_objects_to_default()

        self._set_to_init_pose()

        for _ in range(20):
            self.world.step(render=True)

        self._obs_history.clear()
        self._initial_eef_rot = None
        self._last_eef_pos = None
        self._last_eef_rot = None

        # Recalibrate IK solver after reset
        if self.lula_solver is not None and self.manipulator is not None:
            robot_pos, robot_quat = self.manipulator.get_world_pose()
            self.lula_solver.set_robot_base_pose(
                robot_position=robot_pos, robot_orientation=robot_quat
            )

        # Capture initial observation and set initial rotation
        obs = self._capture_observation()

        # Store initial rotation for relative observations
        if self.art_kine_solver is not None:
            ee_pos, ee_rot_mat = self._get_end_effector_pose()
            self._initial_eef_rot = ee_rot_mat.copy()
            # Initialize last pose tracking for relative action conversion
            self._last_eef_pos = ee_pos.copy()
            self._last_eef_rot = ee_rot_mat.copy()

        self._update_history(obs)
        return self._stack_history()

    def _convert_relative_to_absolute_pose(
        self,
        rel_pos: np.ndarray,
        rel_rot_mat: np.ndarray,
        base_pos: np.ndarray,
        base_rot_mat: np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray]:
        # 1. 修正位置：將相對位移旋轉到世界座標系，再加在 base_pos 上
        # abs_pos = (base_rot_mat * rel_pos) + base_pos
        abs_pos = base_rot_mat @ rel_pos + base_pos
        
        # 2. 修正旋轉：
        # UMI 標準通常是: abs_rot = rel_rot @ base_rot
        abs_rot_mat = rel_rot_mat @ base_rot_mat
        
        return abs_pos, abs_rot_mat

    def step(self, action: np.ndarray) -> Tuple[Dict[str, np.ndarray], float, bool, Dict[str, Any]]:
        # 1. 在畫新軌跡前，先清除舊的
        self.debug_draw.clear_lines()
        self.debug_draw.clear_points()
        # 1. 鎖定觀測時的位姿作為相對基準
        current_ee_pos, current_ee_rot_mat = self._get_end_effector_pose()
        # 如果你用的是 draw_lines_spline，通常也會被 clear_lines 清除
        # --- 軌跡視覺化開始 ---
        traj_points = []
        for i in range(len(action)):
            # 拿到第 i 步的相對動作
            rel_pos = action[i, :3]
            rel_rot6d = action[i, 3:9]
            
            # 轉換為絕對座標
            # 注意：這裡要呼叫你修正後的 _convert_relative_to_absolute_pose
            abs_pos, abs_rot_mat = self._convert_relative_to_absolute_pose(
                rel_pos, 
                rot6d_to_rotation_matrix(rel_rot6d), 
                current_ee_pos, 
                current_ee_rot_mat
            )
            traj_points.append(abs_pos)
            
            # 每隔幾步畫一個座標軸 (Frame)，避免畫面太亂
            if i == 0:
                self.draw_frame(abs_pos, abs_rot_mat, scale=0.05)

        # 畫出白色軌跡線
        if len(traj_points) > 1:
            self.draw_trajectory(traj_points, color=(1, 1, 1, 1), thickness=2)
        # --- 軌跡視覺化結束 ---
        # 2. 發送控制指令 (apply_action)
        self._apply_action(action, base_pos=current_ee_pos, base_rot_mat=current_ee_rot_mat)

        # 3. 【關鍵修正】連續跑多步模擬，讓機器人「追上」目標
        # 假設你的 Policy 是 10Hz，這裡跑 6 步 (6 * 1/60s = 0.1s)
        # 3. 【關鍵】給物理引擎足夠的時間讓機器人移動
        # 假設控制頻率 10Hz，模擬頻率 60Hz，則需跑 6 步
        for _ in range(6):
            self.world.step(render=True)

        # 4. 取得新的觀測並更新歷史
        obs = self._capture_observation()
        self._update_history(obs)
        
        # 更新最後位姿追蹤
        self._last_eef_pos, self._last_eef_rot = self._get_end_effector_pose()
        print(f"Last EEF Pos: {self._last_eef_pos} Rot Mat:\n{self._last_eef_rot}")

        return self._stack_history(), 0.0, False, {"episode_record": obs}

    def _apply_action(self, action: np.ndarray, base_pos=None, base_rot_mat=None) -> None:
        if self.art_kine_solver is None or self.manipulator is None:
            return

        # 1. 解析 Action
        action_step = action[0] if action.ndim > 1 else action
        rel_pos = action_step[:3]
        rel_rot6d = action_step[3:9]
        gripper_width = action_step[9]

        # 2. 座標轉換 (Relative -> Absolute)
        if self.action_pose_repr in ("rel", "relative"):
            ref_pos = base_pos if base_pos is not None else self._last_eef_pos
            ref_rot = base_rot_mat if base_rot_mat is not None else self._last_eef_rot
            abs_pos, abs_rot_mat = self._convert_relative_to_absolute_pose(
                rel_pos, rot6d_to_rotation_matrix(rel_rot6d), ref_pos, ref_rot
            )
        else:
            abs_pos, abs_rot_mat = rel_pos, rot6d_to_rotation_matrix(rel_rot6d)

        # 3. IK 解算 (計算手臂 7 軸)
        rot = R.from_matrix(abs_rot_mat)
        quat_xyzw = rot.as_quat()
        quat_wxyz = np.array([quat_xyzw[3], quat_xyzw[0], quat_xyzw[1], quat_xyzw[2]])

        action_result, success = self.art_kine_solver.compute_inverse_kinematics(
            target_position=abs_pos, 
            target_orientation=quat_wxyz
        )
        print(f"[IK] Target Pos: {abs_pos}, Success: {success}")
        print(f"[IK] Joint Positions: {action_result.joint_positions}")
        print(f"[IK] Gripper Width Target: {gripper_width}")
        if success:
            from isaacsim.core.utils.types import ArticulationAction
            
            # --- 步驟 A: 準備手臂目標 (7 DoF) ---
            arm_joint_targets = action_result.joint_positions
            
            # --- 步驟 B: 準備夾爪目標 (2 DoF) ---
            # Franka 夾爪通常是兩個手指，每個手指移動 width / 2
            # 這裡假設夾爪關節範圍是 0 到 0.04 (總寬 0.08)
            finger_joint_target = gripper_width / 2.0 
            gripper_joint_targets = np.array([finger_joint_target, finger_joint_target])

            # --- 步驟 C: 合併成 9 DoF 向量 ---
            # 注意：這裡假設你的機器人關節順序是 [Arm_0...Arm_6, Finger_1, Finger_2]
            # 這是 Franka Panda 的標準順序
            full_joint_targets = np.concatenate([arm_joint_targets, gripper_joint_targets])

            # --- 步驟 D: 一次性發送指令 ---
            self.manipulator.apply_action(
                ArticulationAction(joint_positions=full_joint_targets)
            )
            
            # --- 步驟 E: 強制設定高剛性 (防止下垂) ---
            # 為了效能，這段建議放在初始化 (init) 裡做一次就好，但在這裡測試確保有效
            # Kp (Stiffness) 設高，Kd (Damping) 適中
            # Arm: Kp=1e5, Kd=1e3 | Gripper: Kp=1e4, Kd=1e2
            self._last_eef_pos, self._last_eef_rot = self._get_end_effector_pose()
            print(f"Last EEF Pos: {self._last_eef_pos} Rot Mat:\n{self._last_eef_rot}")
            # 獲取手腕位置
            hand_pos = self.manipulator.get_world_pose()[0]
            # 獲取你設定的 TCP 位置
            tcp_pos = self.manipulator.end_effector.get_world_pose()[0]
            print(f"Hand Z: {hand_pos[2]}, TCP Z: {tcp_pos[2]}, Target Z: {abs_pos[2]}")

        else:
            print(f"[IK Failed] Target: {abs_pos}")
            # IK 失敗時，至少要維持夾爪動作
            set_gripper_width(self.manipulator, gripper_width) # 只有失敗時才單獨叫這個

    def close(self) -> None:
        if self.simulation_app:
            self.simulation_app.close()
            self.simulation_app = None
    def calibrate_robot_base(self, panda, lula_solver):
        """
        Update Lula solver with current robot base pose.
        Must be called before computing IK.
        
        Args:
            panda: Panda articulation object
            lula_solver: LulaKinematicsSolver instance
        """
        robot_pos, robot_quat = panda.get_world_pose()
        lula_solver.set_robot_base_pose(
            robot_position=robot_pos,
            robot_orientation=robot_quat
        )
    def get_end_effector_pos_quat_wxyz(self, panda, lula_solver, art_kine_solver):
        base_pos, base_quat = panda.get_world_pose()
        lula_solver.set_robot_base_pose(robot_position=base_pos, robot_orientation=base_quat)

        ee_pos, ee_T = art_kine_solver.compute_end_effector_pose()  # ee_T[:3,:3] rotation
        quat_xyzw = R.from_matrix(ee_T[:3, :3]).as_quat()
        quat_wxyz = quat_xyzw[[3, 0, 1, 2]]
        return ee_pos.astype(np.float64), quat_wxyz.astype(np.float64)
    def _set_to_init_pose(self):
        print(f'[Init] Setting to init pose for task: {self.task_name}')

        self.calibrate_robot_base(self.manipulator, self.lula_solver)

        # 1. 取得當前 EE 位置（用於計算 task 特定偏移）
        curr_pos, _ = self.get_end_effector_pos_quat_wxyz(
            self.manipulator, self.lula_solver, self.art_kine_solver
        )

        # 2. 根據 task 設定固定初始 EE 位姿
        if self.task_name == "kitchen":
            INIT_EE_POS = curr_pos + np.array([-0.16, 0., 0.13])
            INIT_EE_QUAT_WXYZ = np.array([0.0081739, -0.9366365, 0.350194, 0.0030561])
        elif self.task_name == "dining-room":
            INIT_EE_POS = curr_pos + np.array([-0.16, 0., 0.13])
            INIT_EE_QUAT_WXYZ = np.array([0.0081739, -0.9366365, 0.350194, 0.0030561])
        elif self.task_name == "living-room":
            INIT_EE_POS = curr_pos + np.array([-0.1, 0.2, 0.20])
            INIT_EE_QUAT_WXYZ = np.array([0.0081739, -0.9366365, 0.350194, 0.0030561])
        else:
            raise RuntimeError(f"Unknown task, expected one of 'kitchen', 'dining-room', 'living-room', got {self.task_name}")

        # 3. IK 與設定
        success = self.apply_ik_solution(
            INIT_EE_POS,
            INIT_EE_QUAT_WXYZ,
        )

        if success:
            print(f"[Init] Success: Moved EE to INIT_EE_POS {INIT_EE_POS}")
        else:
            print("=" * 50)
            print("[IsaacSimEnvironment] WARNING: Failed to apply initial EE pose")
            print(f"  Target Pos: {INIT_EE_POS}, Target Quat WXYZ: {INIT_EE_QUAT_WXYZ}")
            print(f"  Current Pos: {curr_pos}")
            print("Proceeding with current pose...")
            print("=" * 50)



# --- Utility functions ---


def _register_resolvers() -> None:
    if OmegaConf is None:
        return
    try:
        OmegaConf.register_new_resolver("eval", eval, replace=True)  # type: ignore
    except Exception:
        pass


class AttrDict(dict):
    """Minimal dict that supports attribute access (obj.key)."""

    def __getattr__(self, item):
        try:
            return self[item]
        except KeyError as exc:
            raise AttributeError(item) from exc

    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


def _import_from_string(path: str):
    candidates = [path]
    if "env_runners." in path:
        candidates.append(path.replace("env_runners.", "env_runner."))

    last_err: Optional[Exception] = None
    for candidate in candidates:
        try:
            module_name, attr_name = candidate.rsplit(".", 1)
            module = importlib.import_module(module_name)
            return getattr(module, attr_name)
        except Exception as exc:
            last_err = exc
            continue
    raise last_err if last_err else ImportError(f"Could not import {path}")


def _to_container(cfg: Any) -> Dict[str, Any]:
    if OmegaConf is not None and OmegaConf.is_config(cfg):
        return OmegaConf.to_container(cfg, resolve=True)  # type: ignore
    if isinstance(cfg, dict):
        return dict(cfg)
    if hasattr(cfg, "items"):
        return dict(cfg)  # type: ignore
    return {}


def _instantiate(cfg: Any):
    if isinstance(cfg, dict):
        if "_target_" in cfg:
            target = cfg["_target_"]
            kwargs = {k: _instantiate(v) for k, v in cfg.items() if k != "_target_"}
            cls = _import_from_string(target)
            return cls(**kwargs)
        return AttrDict({k: _instantiate(v) for k, v in cfg.items()})
    if isinstance(cfg, list):
        return [_instantiate(v) for v in cfg]
    if isinstance(cfg, tuple):
        return tuple(_instantiate(list(cfg)))
    return cfg


def main():
    parser = argparse.ArgumentParser(
        description="Run Isaac Sim policy evaluation without Hydra."
    )
    parser.add_argument(
        "--task",
        type=str,
        choices=["kitchen", "dining-room", "living-room"],
        required=True,
        help="Task name for registry configuration",
    )
    parser.add_argument(
        "--checkpoint", required=True, help="Path to checkpoint .ckpt file"
    )
    parser.add_argument("--output-dir", required=True, help="Directory to save logs")
    parser.add_argument("--device", default="cuda:0", help="Torch device for policy")
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Run simulation in headless mode",
    )
    args = parser.parse_args()

    _register_resolvers()

    output_dir = pathlib.Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"Loading checkpoint from {args.checkpoint}...")
    # Load checkpoint to CPU first to avoid initializing CUDA before Isaac Sim
    payload = torch.load(
        open(args.checkpoint, "rb"), pickle_module=dill, map_location="cpu"
    )
    cfg = payload["cfg"]

    shape_meta = None
    if hasattr(cfg, "shape_meta"):
        shape_meta = _to_container(cfg.shape_meta)

    # Extract pose representation configuration from checkpoint
    # This determines how observations and actions are represented (absolute vs relative)
    pose_repr = {}
    if getattr(cfg, "task", None) is not None:
        task_cfg = cfg.task
        if hasattr(task_cfg, "dataset") and hasattr(task_cfg.dataset, "pose_repr"):
            pose_repr = _to_container(task_cfg.dataset.pose_repr)
        elif hasattr(task_cfg, "pose_repr"):
            pose_repr = _to_container(task_cfg.pose_repr)

    # Also check env_runner for pose_repr
    if not pose_repr and getattr(cfg, "task", None) is not None:
        env_runner_cfg = getattr(cfg.task, "env_runner", None)
        if env_runner_cfg is not None and hasattr(env_runner_cfg, "pose_repr"):
            pose_repr = _to_container(env_runner_cfg.pose_repr)

    print(f"Pose representation config: {pose_repr}")

    # Get runner target from task name
    runner_target = TASK_RUNNER_MAP.get(args.task)
    if not runner_target:
        raise RuntimeError(
            f"No runner configured for task: {args.task}. "
            f"Available tasks: {list(TASK_RUNNER_MAP.keys())}"
        )

    # Extract runner configuration from checkpoint (for n_episodes, max_steps, etc.)
    runner_cfg = {}
    if getattr(cfg, "task", None) is not None:
        runner_cfg = _to_container(getattr(cfg.task, "env_runner", {}))

    # Build sim_config from runner config and CLI args
    sim_config = runner_cfg.get("sim_config", {})
    if args.headless:
        sim_config["headless"] = True

    # 1. Initialize Isaac Sim Environment FIRST (before CUDA)
    # Uses registry for configuration based on --task argument
    print(f"Initializing Isaac Sim Environment for task: {args.task}...")
    isaac_env = IsaacSimEnvironment(
        task_name=args.task,
        sim_config=sim_config,
        shape_meta=shape_meta,
        pose_repr=pose_repr,
    )

    # 2. Instantiate Policy and move to GPU (after SimApp is running)
    print("Instantiating Policy...")
    policy_cfg = _to_container(getattr(cfg, "policy", {}))
    if shape_meta is not None:
        policy_cfg.setdefault("shape_meta", shape_meta)

    policy = _instantiate(policy_cfg)

    state_dicts = payload.get("state_dicts", {})
    if "model" in state_dicts:
        policy.load_state_dict(state_dicts["model"], strict=False)

    ema_policy = None
    if (
        getattr(getattr(cfg, "training", None), "use_ema", False)
        and "ema_model" in state_dicts
    ):
        ema_policy = _instantiate(policy_cfg)
        ema_policy.load_state_dict(state_dicts["ema_model"], strict=False)

    active_policy = ema_policy or policy

    device = torch.device(args.device)
    active_policy.to(device)
    active_policy.eval()

    # 3. Instantiate the Runner with the existing environment
    print(f"Instantiating Runner: {runner_target}")
    # Extract runner kwargs from checkpoint config (excluding _target_)
    runner_kwargs = {k: v for k, v in runner_cfg.items() if k != "_target_"}

    if shape_meta is not None:
        runner_kwargs.setdefault("shape_meta", shape_meta)

    # Inject the pre-initialized environment and task_name for registry lookup
    runner_kwargs["env"] = isaac_env
    runner_kwargs["task_name"] = args.task

    # Instantiate the runner
    env_runner = _instantiate(
        {"_target_": runner_target, **runner_kwargs, "output_dir": str(output_dir)}
    )

    # 4. Run Evaluation
    print("Starting evaluation...")
    runner_log = env_runner.run(active_policy)

    # Save logs
    json_log = {}
    for key, value in runner_log.items():
        if hasattr(value, "_path"):  # wandb video-like objects
            json_log[key] = value._path
        else:
            try:
                json.dumps(value)
                json_log[key] = value
            except TypeError:
                json_log[key] = str(value)

    out_path = output_dir.joinpath("eval_log.json")
    with out_path.open("w") as f:
        json.dump(json_log, f, indent=2, sort_keys=True)

    print(f"Evaluation complete. Results saved to {out_path}")
    print(f"Success rate: {runner_log.get('success_rate', 'N/A')}")

    if hasattr(env_runner, "close"):
        try:
            env_runner.close()
        except Exception:
            pass


if __name__ == "__main__":
    main()
